# Poner indicadores de progreso en el modelo y actualizar desde agent
# Poner visualización
# Cargar pesos preentrenados

import numpy as np
import random
import agentpy as ap
import json
import os

# Centralized constants import (keeps backwards compat variable names)
from config_constants import (
    JSON_INITIALIZATION, PRETRAIN_ENABLED, VISUALIZATION_ENABLED,
    CYCLE_DELIVERIES_TARGET, ACTIONS, MOVE_TO_HEADING, ACTION_TO_UNITY,
    ALPHA, GAMMA, EPSILON_START, EPSILON_END, DECAY_STEPS, EPSILON_TAU,
    FEAT_PER_ACT, N_FEATURES, R_STEP, R_SHAPING_K, R_PICKUP, R_DROP, R_RECHARGE,
    R_BUMP, R_CONFLICT, LOW_BATT_THR, R_LOW_BATT, R_PROXIMITY_BONUS, R_ADJACENT_BONUS, R_INEFFICIENCY_PENALTY
)

## (legacy constant block folded into config_constants.py)

# =========================== Helpers ================================
def is_adjacent(pos1:tuple, pos2:tuple):
    x1, y1 = pos1
    x2, y2 = pos2
    return (abs(x1-x2) + abs(y1-y2) == 1)

def neighbors4(x, y):
    """Vecindario 4-direcciones, sin filtrar bordes/bloqueo."""
    return [(x-1,y), (x+1,y), (x, y-1), (x, y+1)]

DIRS = {
    "LEFT":  (-1, 0),
    "RIGHT": ( 1, 0),
    "UP":    ( 0,-1),
    "DOWN":  ( 0, 1),
}

def next_pos_from_action(model, pos, action):
    x, y = pos
    if action in DIRS:
        dx, dy = DIRS[action]
        cand = (x + dx, y + dy)
        return cand if model.cell_is_free(cand) else (x, y)
    return (x, y)

def approach_cells_to_box(model, box_loc, robot=None):
    """
    Celdas válidas para hacer PICKUP: adyacentes libres a la celda de la caja.
    box_loc es la celda REAL de la caja (en el rack).
    Now considers robot capabilities for high-level boxes.
    """
    if box_loc is None or not isinstance(box_loc, (list, tuple)) or len(box_loc) < 2:
        return []
    
    # Check if robot can access this box level using new level system
    if robot is not None and len(box_loc) >= 3:
        box_level = int(box_loc[2]) if box_loc[2] is not None else 1
        robot_access_levels = getattr(robot, 'access_levels', [1, 2])  # Default to levels 1,2
        if box_level not in robot_access_levels:
            return []  # Robot can't access this box level
    
    bx, by = box_loc[0], box_loc[1]
    return [p for p in neighbors4(bx, by) if model.cell_is_free(p)]

def get_guidance_lines_for_box(model, box_location):
    """
    Generate vertical guidance lines on left and right sides of a specific box.
    Lines extend the full height of the grid to encourage movement towards the box.
    Returns a set of (x, y) positions that are on guidance lines for this box.
    """
    guidance_positions = set()
    
    if not isinstance(box_location, (list, tuple)) or len(box_location) < 2:
        return guidance_positions
    
    try:
        bx = int(box_location[0])
        
        # Add full-height vertical lines on left and right sides of the target box
        for y in range(model.H):  # Full grid height
            # Left side guidance line (entire column)
            left_pos = (bx - 1, y)
            if model.cell_is_free(left_pos):
                guidance_positions.add(left_pos)
            
            # Right side guidance line (entire column)
            right_pos = (bx + 1, y)
            if model.cell_is_free(right_pos):
                guidance_positions.add(right_pos)
                
    except (ValueError, TypeError):
        pass
    
    return guidance_positions

def get_guidance_lines_for_boxes(model):
    """
    Generate vertical guidance lines on left and right sides of all boxes.
    Returns a set of (x, y) positions that are on guidance lines.
    This is used for visualization purposes.
    """
    guidance_positions = set()
    
    if not hasattr(model, 'boxes') or not model.boxes:
        return guidance_positions
    
    for box in model.boxes:
        try:
            if isinstance(box, dict) and 'pos' in box:
                pos = box['pos']
                if isinstance(pos, (list, tuple)) and len(pos) >= 2:
                    bx = int(pos[0])
                    
                    # Add full-height vertical lines on left and right sides of box
                    for y in range(model.H):  # Full grid height
                        # Left side guidance line
                        left_pos = (bx - 1, y)
                        if model.cell_is_free(left_pos):
                            guidance_positions.add(left_pos)
                        
                        # Right side guidance line  
                        right_pos = (bx + 1, y)
                        if model.cell_is_free(right_pos):
                            guidance_positions.add(right_pos)
        except (ValueError, TypeError, KeyError):
            continue
    
    return guidance_positions

def is_on_guidance_line_for_box(model, position, box_location):
    """
    Check if a position is on a vertical guidance line next to a specific target box.
    Returns True if position is on a guidance line for the target box, False otherwise.
    """
    if not isinstance(position, (tuple, list)) or len(position) < 2:
        return False
    
    if not isinstance(box_location, (list, tuple)) or len(box_location) < 2:
        return False
    
    try:
        x, y = int(position[0]), int(position[1])
        bx = int(box_location[0])
        
        # Check if position is on vertical line to left or right of the target box
        # Lines extend full height, so we only check x-coordinates
        if (x == bx - 1 or x == bx + 1):
            return model.cell_is_free((x, y))
            
    except (ValueError, TypeError):
        pass
    
    return False

def goal_cells(model, robot, box_location):
    """
    Objetivo según misión:
    - DELIVERY, sin caja: aproximación a la caja (celdas libres adyacentes a box_location)
    - DELIVERY, con caja: celda DROP exacta (robot.target)
    - RECHARGE: celda del cargador (robot.target)
    - RESTING: celda de descanso (robot.target) para que se desplace hacia allí
    """
    if robot.mission == "DELIVERY":
        if not robot.carrying:
            # box_location puede ser (x,y,h)
            if isinstance(box_location, (list, tuple)) and len(box_location) >= 2:
                return approach_cells_to_box(model, (box_location[0], box_location[1]), robot)
            return approach_cells_to_box(model, box_location, robot)
        if robot.target is not None:
            tgt = robot.target
            if isinstance(tgt, (list, tuple)) and len(tgt) >= 2:
                return [tuple(tgt[:2])]
            elif isinstance(tgt, (list, tuple)):
                return [tgt]
            else:
                return []
    elif robot.mission == "RECHARGE":
        if robot.target is not None:
            tgt = robot.target
            if isinstance(tgt, (list, tuple)) and len(tgt) >= 2:
                return [tuple(tgt[:2])]
            elif isinstance(tgt, (list, tuple)):
                return [tgt]
            else:
                return []
    elif robot.mission == "RESTING":
        if robot.target is not None:
            tgt = robot.target
            if isinstance(tgt, (list, tuple)) and len(tgt) >= 2:
                return [tuple(tgt[:2])]
            elif isinstance(tgt, (list, tuple)):
                return [tgt]
            else:
                return []
    return []

def closest_goal_and_dist(from_pos, goals):
    """Devuelve (gx, gy, dist) a la meta Manhattan más cercana. Si no hay metas: (from_pos, 0)."""
    if not goals:
        x, y = from_pos
        return x, y, 0
    x, y = from_pos
    best = None
    best_d = None
    for gx, gy in goals:
        d = abs(x - gx) + abs(y - gy)
        if best_d is None or d < best_d:
            best = (gx, gy)
            best_d = d
    return best[0], best[1], best_d

def manhattan(pos:tuple, target:tuple):
    x, y = pos
    xt = target[0]
    yt = target[1]
    return abs(xt-x) + abs(yt-y)

# ========================= Q-LEARNING ===============================
## (reward & feature constants imported)

def q_function(model, robot, action, box_location=None):
    """
    Q(s,a) = w^T φ(s,a)
    - model.global_weights: vector de pesos global de tamaño N_FEATURES
    - φ: vector por-bloques de tamaño N_FEATURES (FEAT_PER_ACT * len(ACTIONS))
    """
    if not hasattr(model, "global_weights") or len(model.global_weights) != N_FEATURES:
        model.global_weights = np.zeros(N_FEATURES, dtype=np.float32)

    f_sa = phi(model, robot, action, box_location)  # (N_FEATURES,)

    return float(np.dot(model.global_weights, f_sa))

def reward_fun(model, robot, action, prev_pos, next_pos, box_location=None, forced_wait_by_conflict=False):
    r = R_STEP

    goals = goal_cells(model, robot, box_location)
    if goals:
        _, _, d_prev = closest_goal_and_dist(prev_pos, goals)
        _, _, d_next = closest_goal_and_dist(next_pos, goals)
        
        # Enhanced distance shaping with stronger incentive
        distance_improvement = d_prev - d_next
        r += R_SHAPING_K * distance_improvement
        
        # Proximity bonuses - encourage getting very close to targets
        if d_next <= 3:  # Within 3 cells of goal
            r += R_PROXIMITY_BONUS
        if d_next <= 1:  # Adjacent to goal
            r += R_ADJACENT_BONUS
            
        # Inefficiency penalty - discourage moving away from target
        if distance_improvement < 0:  # Moving away from target
            r -= R_INEFFICIENCY_PENALTY

    # OJO: ahora revisamos estado POST-ACCIÓN (porque ya actualizaste en act())
    if action == "PICKUP" and robot.carrying:  # acaba de recoger
        if tuple(prev_pos) in approach_cells_to_box(model, box_location, robot):
            r += R_PICKUP

    if action == "DISCHARGE" and (not robot.carrying):  # acaba de descargar
        if robot.target is not None:
            tgt = robot.target
            tgt_xy = tuple(tgt[:2]) if isinstance(tgt, (list, tuple)) and len(tgt) >= 2 else tuple(tgt)
            if tuple(prev_pos) == tgt_xy:
                r += R_DROP

    if action == "RECHARGE" and tuple(prev_pos) in getattr(model, "recharge_points", []):
        r += R_RECHARGE

    # Small bonus for reaching resting points to avoid lingering
    if robot.mission == "RESTING" and robot.target is not None:
        tgt = robot.target
        tgt_xy = tuple(tgt[:2]) if isinstance(tgt, (list, tuple)) and len(tgt) >= 2 else tuple(tgt)
        if tuple(next_pos) == tgt_xy:
            r += 0.5  # Small completion bonus for reaching rest point

    if action in {"UP","DOWN","LEFT","RIGHT"} and tuple(next_pos) == tuple(prev_pos):
        r += R_BUMP

    if forced_wait_by_conflict:
        r += R_CONFLICT
    elif action == "WAIT":
        # Extra penalty for waiting when not forced by conflict
        r -= 0.05  # Encourage active exploration over waiting

    batt = float(getattr(robot, "battery", 100)) / 100.0
    if batt < LOW_BATT_THR and action != "RECHARGE":
        r += R_LOW_BATT

    # Guidance line bonus: encourage robots to move along vertical paths next to target boxes
    if action in {"UP", "DOWN", "LEFT", "RIGHT"} and tuple(next_pos) != tuple(prev_pos):
        # Check if robot is on delivery mission and moving along guidance lines
        if robot.mission == "DELIVERY" and not robot.carrying and box_location is not None:
            # Moving towards the target box - encourage using guidance lines for that specific box
            if is_on_guidance_line_for_box(model, next_pos, box_location):
                r += 0.6  # Stronger bonus for following guidance lines to target box
                
                # Extra bonus if moving towards the box (getting closer)
                if isinstance(box_location, (list, tuple)) and len(box_location) >= 2:
                    box_x = box_location[0]
                    robot_x = next_pos[0]
                    prev_x = prev_pos[0]
                    
                    # Check if robot is moving horizontally towards the box
                    if abs(robot_x - box_x) < abs(prev_x - box_x):
                        r += 0.4  # Stronger bonus for moving closer to target box
        
        # Penalty for entering narrow aisles without using guidance lines
        if model.is_narrow_aisle(next_pos):
            guidance_positions = get_guidance_lines_for_boxes(model)
            if (int(next_pos[0]), int(next_pos[1])) not in guidance_positions:
                r -= 0.3  # Penalty for entering narrow aisles inappropriately
        
        # Anti-oscillation penalty
        if hasattr(robot, 'stuck_counter') and robot.stuck_counter >= 2:
            r -= 0.2  # Penalty for oscillating behavior

    return float(r)

def phi(model, robot, action, box_location=None):
    """
    φ por bloques de acción (12 features, con dx/dy y extras opcionales).
    Solo se llena el bloque de la acción actual; los demás van en cero.

    Bloque de 12:
      [0] bias_act        = 1.0
      [1] dist_next_norm  = dist(next -> goal) / max_dist
      [2] dx_norm         = (gx - x_next) / max_dx
      [3] dy_norm         = (gy - y_next) / max_dy
      [4] carrying        = 0/1
      [5] is_wait         = 1 si WAIT
      [6] is_pick         = 1 si PICKUP
      [7] is_drop         = 1 si DISCHARGE
      [8] is_recharge     = 1 si RECHARGE
      [9] battery_norm    = battery / 100
      [10] col_w_norm     = peso de columna normalizado [0..1] (si aplica)
      [11] acc_flag       = 1 si caja accesible (adyacencia libre), 0 en otro caso
    """
    # normalizadores
    W = max(1, getattr(model, "W", 0))
    H = max(1, getattr(model, "H", 0))
    max_dx = max(1, W - 1)
    max_dy = max(1, H - 1)
    max_dist = max_dx + max_dy

    # pos tentativa tras aplicar acción
    x, y = robot.position
    x_next, y_next = next_pos_from_action(model, (x, y), action)

    # metas
    goals = goal_cells(model, robot, box_location)
    gx, gy, dist_next = closest_goal_and_dist((x_next, y_next), goals)

    dist_next_norm = dist_next / max_dist
    dx_norm = (gx - x_next) / max_dx
    dy_norm = (gy - y_next) / max_dy

    # indicadores
    carrying     = 1.0 if robot.carrying else 0.0
    is_wait      = 1.0 if action == "WAIT" else 0.0
    is_pick      = 1.0 if action == "PICKUP" else 0.0
    is_drop      = 1.0 if action == "DISCHARGE" else 0.0
    is_recharge  = 1.0 if action == "RECHARGE" else 0.0
    battery_norm = float(getattr(robot, "battery", 100)) / 100.0

    # extras: col_w_norm y accesibilidad
    col_w_norm = 0.0
    acc_flag = 0.0
    try:
        if box_location is not None:
            bx = box_location[0] if isinstance(box_location, (list, tuple)) and len(box_location) >= 2 else None
            by = box_location[1] if isinstance(box_location, (list, tuple)) and len(box_location) >= 2 else None
            if bx is not None and by is not None:
                if hasattr(model, 'get_col_weight'):
                    cw = float(model.get_col_weight((bx, by)))
                    maxw = getattr(model, 'col_weight_max', 1.0) or 1.0
                    col_w_norm = max(0.0, min(1.0, cw / maxw))
                if hasattr(model, 'box_is_accessible'):
                    acc_flag = 1.0 if model.box_is_accessible((bx, by, 0)) else 0.0
    except Exception:
        pass

    # vector por bloques
    f = np.zeros(FEAT_PER_ACT * len(ACTIONS), dtype=np.float32)
    try:
        aidx = ACTIONS.index(action)
    except ValueError:
        aidx = ACTIONS.index("UP")

    off = FEAT_PER_ACT * aidx
    f[off + 0] = 1.0
    f[off + 1] = dist_next_norm
    f[off + 2] = dx_norm
    f[off + 3] = dy_norm
    f[off + 4] = carrying
    f[off + 5] = is_wait
    f[off + 6] = is_pick
    f[off + 7] = is_drop
    f[off + 8] = is_recharge
    f[off + 9] = battery_norm
    f[off + 10] = col_w_norm
    f[off + 11] = acc_flag

    return f

#  ========================= AGENTE ================================
DEFAULT_CONF = {
    "carrying": 0,
    "battery": 100,
    "target": None,
    "r_type": "A",
    "mission": None,
    "position": (0,0)
}

class Robot(ap.Agent):
    def setup(self, robot_conf=DEFAULT_CONF):
        if JSON_INITIALIZATION:
            pass

        self.carrying = bool(robot_conf.get("carrying", 0))
        self.battery = robot_conf.get("battery", 100)
        self.target = robot_conf.get("target", None)
        self.r_type = robot_conf.get("r_type", "A")
        pos = robot_conf.get("position", (0, 0))
        if isinstance(pos, (list, tuple)) and len(pos) >= 2:
            self.position = (pos[0], pos[1])
        else:
            self.position = (0, 0)
        self.mission = robot_conf.get("mission", None)
        self.proposal = None

        self.box_location = None
        self.last_phi = None
        # Unity integration: default heading (0=UP) and last action string
        self.last_heading = 0
        self.last_action_str = "idle"
        
        # Anti-oscillation system
        self.movement_history = []  # Track last 4 movements
        self.stuck_counter = 0      # Count consecutive similar movements

    def json_setup(self, info):
        self.carrying = bool(info.get("carrying", 0))
        self.battery = info.get("battery", 100)
        self.target = info.get("target", None)
        self.r_type = info.get("r_type", "A")
        pos = info.get("position", info.get("pos", (0, 0)))
        if isinstance(pos, (list, tuple)) and len(pos) >= 2:
            self.position = (pos[0], pos[1])
        else:
            self.position = (0, 0)
        self.mission = info.get("mission", None)
        # Mantener id existente si no viene en el JSON
        if "id" in info:
            self.id = info["id"]
        self.proposal = None

        self.box_location = None
        self.last_phi = None
        # Unity integration: default heading (0=UP) and last action string
        self.last_heading = 0
        self.last_action_str = "idle"
        
        # Anti-oscillation system
        self.movement_history = []  # Track last 4 movements
        self.stuck_counter = 0      # Count consecutive similar movements

    def set_robot_id(self, rid):
        self.id = int(rid)
    
    def detect_oscillation(self, proposed_action):
        """Detect if robot is oscillating between positions"""
        if proposed_action not in ["UP", "DOWN", "LEFT", "RIGHT"]:
            return False
            
        # Keep track of last 4 movements
        self.movement_history.append(proposed_action)
        if len(self.movement_history) > 4:
            self.movement_history.pop(0)
            
        # Check for oscillation patterns (e.g., UP-DOWN-UP-DOWN)
        if len(self.movement_history) >= 4:
            # Check for vertical oscillation
            if (self.movement_history == ["UP", "DOWN", "UP", "DOWN"] or 
                self.movement_history == ["DOWN", "UP", "DOWN", "UP"]):
                self.stuck_counter += 1
                return True
                
            # Check for horizontal oscillation
            if (self.movement_history == ["LEFT", "RIGHT", "LEFT", "RIGHT"] or 
                self.movement_history == ["RIGHT", "LEFT", "RIGHT", "LEFT"]):
                self.stuck_counter += 1
                return True
                
        # Reset counter if no oscillation
        self.stuck_counter = 0
        return False
    
    def get_guidance_line_navigation_action(self, feasible_actions, box_location):
        """Get the best action to move towards guidance lines for target box"""
        if not box_location or self.mission != "DELIVERY" or self.carrying:
            return None
            
        box_x = int(box_location[0]) if len(box_location) > 0 else 0
        current_x, current_y = self.position
        
        # Check if we're already on a guidance line
        if is_on_guidance_line_for_box(self.model, self.position, box_location):
            # We're on a guidance line, now move towards the box
            if current_x < box_x - 1:  # We're too far left, move right to left guidance line
                return "RIGHT" if "RIGHT" in feasible_actions else None
            elif current_x > box_x + 1:  # We're too far right, move left to right guidance line  
                return "LEFT" if "LEFT" in feasible_actions else None
            elif current_x == box_x - 1 or current_x == box_x + 1:
                # We're on the correct guidance line, move vertically towards box
                box_y = int(box_location[1]) if len(box_location) > 1 else 0
                if current_y < box_y:
                    return "DOWN" if "DOWN" in feasible_actions else None
                elif current_y > box_y:
                    return "UP" if "UP" in feasible_actions else None
        else:
            # We're not on a guidance line, move towards the nearest one
            left_guidance_x = box_x - 1
            right_guidance_x = box_x + 1
            
            # Choose the closest guidance line
            dist_to_left = abs(current_x - left_guidance_x)
            dist_to_right = abs(current_x - right_guidance_x)
            
            if dist_to_left <= dist_to_right:
                # Move towards left guidance line
                if current_x < left_guidance_x:
                    return "RIGHT" if "RIGHT" in feasible_actions else None
                elif current_x > left_guidance_x:
                    return "LEFT" if "LEFT" in feasible_actions else None
            else:
                # Move towards right guidance line
                if current_x < right_guidance_x:
                    return "RIGHT" if "RIGHT" in feasible_actions else None
                elif current_x > right_guidance_x:
                    return "LEFT" if "LEFT" in feasible_actions else None
        
        return None

    def get_anti_oscillation_actions(self, feasible_actions, box_location=None):
        """Get alternative actions to break oscillation"""
        alternative_actions = []
        
        # If we have a target box, prefer guidance line movements
        if box_location is not None and self.mission == "DELIVERY" and not self.carrying:
            guidance_action = self.get_guidance_line_navigation_action(feasible_actions, box_location)
            if guidance_action:
                alternative_actions.append(guidance_action)
                
            # Also add direct guidance line movements
            for action in ["LEFT", "RIGHT", "UP", "DOWN"]:
                if action in feasible_actions:
                    next_pos = next_pos_from_action(self.model, self.position, action)
                    if is_on_guidance_line_for_box(self.model, next_pos, box_location):
                        alternative_actions.append(action)
        
        # If no guidance line actions available, try perpendicular movements
        if not alternative_actions:
            recent_moves = self.movement_history[-2:] if len(self.movement_history) >= 2 else []
            if recent_moves:
                last_move = recent_moves[-1]
                # If last move was vertical, try horizontal
                if last_move in ["UP", "DOWN"]:
                    for action in ["LEFT", "RIGHT"]:
                        if action in feasible_actions:
                            alternative_actions.append(action)
                # If last move was horizontal, try vertical
                elif last_move in ["LEFT", "RIGHT"]:
                    for action in ["UP", "DOWN"]:
                        if action in feasible_actions:
                            alternative_actions.append(action)
        
        # Last resort: try WAIT
        if not alternative_actions and "WAIT" in feasible_actions:
            alternative_actions.append("WAIT")
            
        return alternative_actions

    def valid_actions(self, x:int, y:int, carrying:bool, target:tuple, mission:str, box_location:tuple):
        valid = []
        # Prefer movement options first
        for act, (dx, dy) in DIRS.items():
            cand = (x + dx, y + dy)
            if self.model.cell_is_free(cand):
                valid.append(act)

        if mission == "DELIVERY":
            if carrying and target is not None:
                tgt_xy = tuple(target[:2]) if isinstance(target, (list, tuple)) and len(target) >= 2 else tuple(target)
                if (x, y) == tgt_xy:
                    valid.append("DISCHARGE")
            elif (not carrying):
                if isinstance(box_location, (list, tuple)) and len(box_location) >= 2:
                    bx, by = box_location[0], box_location[1]
                    if (x, y) in approach_cells_to_box(self.model, (bx, by), self):
                        valid.append("PICKUP")
                elif box_location is not None:
                    if (x, y) in approach_cells_to_box(self.model, box_location, self):
                        valid.append("PICKUP")

        # Recharge only at actual charger cells. In RESTING, permit only if low battery.
        if (mission == "RECHARGE" and self.battery < 100) or (mission == "RESTING" and self.battery < 10):
            if (not carrying) and target is not None:
                tgt_xy = tuple(target[:2]) if isinstance(target, (list, tuple)) and len(target) >= 2 else tuple(target)
                if (x, y) == tgt_xy and tgt_xy in self.model.recharge_points:
                    valid.append("RECHARGE")

        # WAIT is always feasible; append last so tie-breakers deprioritize it
        valid.append("WAIT")
        return valid

    def plan(self, box_location=None):
        # Enforce preferred drop point target when carrying
        try:
            if self.carrying and hasattr(self, 'drop_pref'):
                dp = getattr(self, 'drop_pref')
                if isinstance(dp, (list, tuple)) and len(dp) >= 2:
                    if (not self.target) or tuple(self.target[:2]) != (dp[0], dp[1]):
                        self.target = (dp[0], dp[1], 0)
                        self.mission = "DELIVERY"
        except Exception:
            pass
        feasible = self.valid_actions(
            *self.position,
            self.carrying,
            self.target,
            self.mission,
            box_location
        )

        # Diagnostics: check opportunities
        had_pick = ("PICKUP" in feasible)
        had_drop = ("DISCHARGE" in feasible)
        if had_pick:
            try:
                self.model.stats["pickup_opportunities"] += 1
            except Exception:
                pass
        if had_drop:
            try:
                self.model.stats["drop_opportunities"] += 1
            except Exception:
                pass

        # Prioritize critical actions deterministically
        if had_drop:
            self.proposal = "DISCHARGE"
        elif had_pick:
            self.proposal = "PICKUP"
        elif ("RECHARGE" in feasible) and (self.battery < 10):
            self.proposal = "RECHARGE"
        else:
            # ε-greedy among remaining feasible actions
            if random.random() > self.model.global_epsilon:  # EXPLOIT (1-ε)
                qvals = {act: q_function(self.model, self, act, box_location) for act in feasible}
                best_action = max(
                    feasible,
                    key=lambda act: (qvals[act], 0 if act != "WAIT" else -1)
                )
                
                # Check for oscillation before committing to action
                if self.detect_oscillation(best_action) and self.stuck_counter >= 2:
                    # Try anti-oscillation actions
                    alternative_actions = self.get_anti_oscillation_actions(feasible, box_location)
                    if alternative_actions:
                        self.proposal = random.choice(alternative_actions)
                        self.stuck_counter = 0  # Reset counter
                    else:
                        self.proposal = best_action
                else:
                    self.proposal = best_action
                    
            else:  # EXPLORE (ε)
                # Enhanced goal-directed exploration with guidance line preference
                goals = goal_cells(self.model, self, box_location)
                if goals:
                    gx, gy, d0 = closest_goal_and_dist(self.position, goals)
                    
                    # Prioritize guidance line movements for delivery missions
                    guidance_actions = []
                    better = []
                    
                    for act in feasible:
                        if act in DIRS:
                            nx, ny = next_pos_from_action(self.model, self.position, act)
                            d1 = abs(gx - nx) + abs(gy - ny)
                            
                            # Check if this move would put us on guidance lines to target box
                            if (self.mission == "DELIVERY" and not self.carrying and 
                                box_location is not None and 
                                is_on_guidance_line_for_box(self.model, (nx, ny), box_location)):
                                guidance_actions.append(act)
                            
                            if d1 < d0:
                                better.append(act)
                    
                    # Smart guidance line navigation during exploration
                    smart_guidance_action = None
                    if (self.mission == "DELIVERY" and not self.carrying and box_location is not None):
                        smart_guidance_action = self.get_guidance_line_navigation_action(feasible, box_location)
                    
                    # Prefer smart guidance navigation first, then guidance line actions, then better moves
                    if smart_guidance_action and random.random() < 0.8:
                        chosen_action = smart_guidance_action
                    elif guidance_actions and random.random() < 0.7:
                        chosen_action = random.choice(guidance_actions)
                    elif better:
                        chosen_action = random.choice(better)
                    else:
                        non_wait = [a for a in feasible if a != "WAIT"]
                        chosen_action = random.choice(non_wait) if non_wait else "WAIT"
                    
                    # Anti-oscillation check during exploration
                    if self.detect_oscillation(chosen_action) and self.stuck_counter >= 2:
                        alternative_actions = self.get_anti_oscillation_actions(feasible, box_location)
                        if alternative_actions:
                            self.proposal = random.choice(alternative_actions)
                            self.stuck_counter = 0
                        else:
                            self.proposal = chosen_action
                    else:
                        self.proposal = chosen_action
                else:
                    non_wait = [a for a in feasible if a != "WAIT"]
                    self.proposal = random.choice(non_wait) if non_wait else "WAIT"

        # Diagnostics: missed critical actions (only if not chosen)
        if had_pick and self.proposal != "PICKUP":
            try:
                self.model.stats["pickup_missed"] += 1
            except Exception:
                pass
        if had_drop and self.proposal != "DISCHARGE":
            try:
                self.model.stats["drop_missed"] += 1
            except Exception:
                pass

        # Guardar el último phi para actualizar después de resolver conflictos
        self.box_location = box_location
        self.last_phi = phi(self.model, self, self.proposal, box_location)

    def act(self):
        self.last_phi = phi(self.model, self, self.proposal, self.box_location)
        prev_pos = self.position
        a = self.proposal

        # Movimiento tentativo
        next_pos = next_pos_from_action(self.model, prev_pos, a)

        # Bump statistic: attempted move but stayed in place
        if a in DIRS and tuple(next_pos) == tuple(prev_pos):
            try:
                self.model.stats["bumps"] += 1
                self.model._bumps_this_step += 1
            except Exception:
                pass

        # Unity-facing action/heading tracking and per-tick action event
        try:
            unity_action = ACTION_TO_UNITY.get(a, "idle")
            # Update robot memory
            self.last_action_str = unity_action
            if a in MOVE_TO_HEADING:
                self.last_heading = int(MOVE_TO_HEADING[a])
            # Collect per-tick actions on the model (cleared each step)
            if hasattr(self.model, 'action_events') and isinstance(self.model.action_events, list):
                self.model.action_events.append({"robot_id": int(getattr(self, 'id', -1)), "action": unity_action})
        except Exception:
            pass

        # Coste/recarga de batería (post-acción)
        if a == "RECHARGE":
            self.battery = min(self.battery + 5, 100)
            # If fully charged, leave charger to a RESTING point
            if self.battery >= 100:
                self.mission = "RESTING"
                rp = self.model.closest_pick(self.position, self.model.resting_points, self.model.resting_point_free)
                self.target = (rp[0], rp[1], 0) if rp is not None else None
        elif a == "WAIT":
            self.battery = max(self.battery - 0.05, 0)
        else:
            self.battery = max(self.battery - 0.10, 0)

        # Actualizar carrying antes de recompensa para coherencia del reward
        if a == "PICKUP":
            self.carrying = True
            self.model.stats["pickups"] += 1
            # Handle visual pickup for box hiding
            if hasattr(self, 'box_location') and self.box_location:
                self.model.handle_box_pickup(self, self.box_location)
            try:
                self.model._picked_this_step += 1
            except Exception:
                pass
        elif a == "DISCHARGE":
            self.carrying = False
            self.model.stats["deliveries"] += 1
            # Handle visual delivery for box respawn
            if hasattr(self, 'box_location') and self.box_location:
                self.model.handle_box_delivery(self, self.box_location)
            # Episodic delivery tracking
            try:
                if getattr(self.model, 'training_mode', False):
                    # Training mode: only count first delivery per robot, cap at robot count
                    if (not hasattr(self, 'deliveries_this_episode') or 
                        self.deliveries_this_episode == 0):
                        # Only count if we haven't exceeded the robot limit
                        if self.model.episode_delivery_count < len(self.model.robots):
                            self.deliveries_this_episode = 1
                            self.model.episode_delivery_count += 1
                            self.model._delivered_this_step += 1
                            # Terminate when we reach the target deliveries
                            if self.model.episode_delivery_count >= len(self.model.robots):
                                self.model.episode_terminated = True
                else:
                    # Visualization mode: count all deliveries
                    if hasattr(self, 'deliveries_this_episode'):
                        self.deliveries_this_episode += 1
                    else:
                        self.deliveries_this_episode = 1
                    self.model._delivered_this_step += 1
            except Exception:
                pass

        # Q(s,a) desde last_phi evita inconsistencias de estado
        current_q = float(np.dot(self.model.global_weights, self.last_phi)) if self.last_phi is not None else q_function(self.model, self, a, self.box_location)

        # Recompensa: para DISCHARGE, aún no cambiamos mission/target para validar DROP correctamente
        reward = reward_fun(self.model, self, a, prev_pos, next_pos, self.box_location,
                            self.id in self.model.forced_wait_by_conflict)
        self.model.stats["reward_hist"].append(reward)
        try:
            self.model.stats["success_hist"].append(1 if reward > 0 else 0)
        except Exception:
            pass

        # Update action statistics
        if a == "WAIT":
            self.model.stats["waits"] += 1
        elif a == "RECHARGE":
            self.model.stats["recharges"] += 1
        elif a in ["UP", "DOWN", "LEFT", "RIGHT"]:
            self.model.stats["moves"] += 1

        # Ahora sí, completar transición de misión/target tras entregar
        if a == "DISCHARGE":
            # Release the drop point reservation
            self.model.release_drop_point(self.id)
            
            # Clear current mission to make robot available for reassignment
            self.mission = None
            self.target = None
            self.box_location = None
            # Clear from current missions
            if hasattr(self.model, 'current_missions') and self.id in self.model.current_missions:
                del self.model.current_missions[self.id]

        # Aplicar la transición de posición al estado siguiente antes de Q(s',a')
        self.position = next_pos

        # Q(s',a') mejor
        feasible = self.valid_actions(*self.position, self.carrying, self.target, self.mission, self.box_location)
        q_vals = [q_function(self.model, self, act, self.box_location) for act in feasible]
        next_best_q = max(q_vals) if q_vals else 0.0

        td = reward + GAMMA * next_best_q - current_q
        self.model.stats["td_hist"].append(td)
        if self.last_phi is not None:
            self.model.global_weights += ALPHA * td * self.last_phi

# ======================== MODELO =====================================
class Warehouse(ap.Model):
    def setup(self):
        # 1. cargar JSON (permite parámetro config_path)
        cfg_path = None
        try:
            # agentpy expone parámetros en self.p
            cfg_path = getattr(self, 'p', {}).get('config_path', 'layout.json')
        except Exception:
            cfg_path = 'layout.json'
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)

        # Validar JSON (best-effort)
        try:
            self._validate_config(cfg)
        except Exception:
            pass

        # 2. diccionario robots
        n_robots = len(cfg.get("robots", []))

        # 3. Process boxes with rack slot mapping
        racks = {r["id"]: r for r in cfg.get("entities", {}).get("racks", [])}
        self.boxes = cfg.get("boxes", [])

        # Convert rack slots to positions
        for b in self.boxes:
            if "pos" not in b and "rack_id" in b and "slot" in b:
                rack = racks.get(b["rack_id"])
                if rack and "rect" in rack:
                    # Calculate position from rack rect and slot
                    rack_rect = rack["rect"]
                    slot = b["slot"]
                    bay = slot.get("bay", 0)
                    level = slot.get("level", 0)
                    
                    # For vertical racks (h > w), bay maps to y-direction
                    # For horizontal racks (w > h), bay maps to x-direction
                    if rack_rect["h"] >= rack_rect["w"]:
                        # Vertical rack
                        x = rack_rect["x"]
                        y = rack_rect["y"] + (bay % rack_rect["h"])
                    else:
                        # Horizontal rack
                        x = rack_rect["x"] + (bay % rack_rect["w"])
                        y = rack_rect["y"]
                    
                    h = level
                    b["pos"] = [x, y, h]

        # Assign box levels based on robot count and new level system:
        # Levels: 1,2 for robots 1&2, levels 3,4 for robots 3&4
        # 1 robot: 1 box level 1
        # 2 robots: 1 box level 1, 1 box level 2  
        # 3 robots: 1 box level 1, 1 box level 2, 1 box level 3
        # 4 robots: 1 box level 1, 1 box level 2, 1 box level 3, 1 box level 4
        
        if n_robots == 1:
            box_levels = [1]  # Only level 1 for robot 1
        elif n_robots == 2:
            box_levels = [1, 2]  # Levels 1,2 for robots 1&2
        elif n_robots == 3:
            box_levels = [1, 2, 3]  # Levels 1,2 for robots 1&2, level 3 for robot 3
        elif n_robots >= 4:
            box_levels = [1, 2, 3, 4]  # All levels
        else:
            box_levels = [1]
        
        total_boxes_needed = len(box_levels)
        
        # Only keep the exact number of boxes needed and assign proper levels
        active_boxes = []
        for i in range(min(total_boxes_needed, len(self.boxes))):
            b = self.boxes[i]
            if isinstance(b, dict) and "pos" in b:
                pos = b["pos"]
                if isinstance(pos, (list, tuple)) and len(pos) >= 2:
                    # Assign level from the progression
                    level = box_levels[i]
                    
                    # Update box position with correct level
                    b_copy = dict(b)  # Make a copy to avoid modifying original
                    if len(pos) >= 3:
                        b_copy["pos"] = [pos[0], pos[1], level]
                    else:
                        b_copy["pos"] = [pos[0], pos[1], level]
                    active_boxes.append(b_copy)
        
        # Replace the boxes list with only the active ones
        self.boxes = active_boxes

        # 4. lista de celdas bloqueadas, puntos de entrega y de recolección
        rows = cfg["tilemap"]["walkable"]
        self.H, self.W = len(rows), len(rows[0])
        legend = cfg["tilemap"]["legend"]
        walkable = [[bool(legend[rows[y][x]]) for x in range(self.W)] for y in range(self.H)]
        self.occupied = {(x,y) for y in range(self.H) for x in range(self.W) if not walkable[y][x]}

        self.drop_points = []
        self.recharge_points = []
        self.spawn_points = []
        self.resting_points = []
        
        # Drop point reservation system to prevent congestion
        self.reserved_drop_points = set()  # Currently reserved drop points
        self.drop_point_assignments = {}   # robot_id -> drop_point mapping

        for cell in cfg.get("tags", []):
            if cell["type"] == "DROP": self.drop_points.append(tuple(cell["pos"]))
            if cell["type"] == "CHARGE": self.recharge_points.append(tuple(cell["pos"]))
            if cell["type"] == "SPAWN": self.spawn_points.append(tuple(cell["pos"]))
            if cell["type"] == "REST": self.resting_points.append(tuple(cell["pos"]))

        # If no explicit REST tags provided, derive resting points away from chargers.
        # Do NOT use SPAWN as resting to avoid clustering on a single spawn cell.
        if not self.resting_points:
            rest_candidates = set()
            for cx, cy in self.recharge_points:
                for nx, ny in neighbors4(cx, cy):
                    if self.cell_is_free((nx, ny)) and (nx, ny) not in self.recharge_points:
                        rest_candidates.add((nx, ny))
            self.resting_points = list(rest_candidates)
        
        # Initialize available spawn points for box respawning (free cells away from service points)
        self._initialize_box_spawn_points()
        
        # Box respawning control - enabled by default for simulation, disabled for training
        self.box_respawn_enabled = getattr(self, 'box_respawn_enabled', True)
        self.training_mode = getattr(self, 'training_mode', False)

        # Pesos de columna opcionales
        self.col_weight = {}
        colw = cfg.get("col_weights")
        if isinstance(colw, list):
            for item in colw:
                try:
                    pos = item.get("pos")
                    w = float(item.get("w", 1.0))
                    if isinstance(pos, (list, tuple)) and len(pos) >= 2:
                        self.col_weight[(int(pos[0]), int(pos[1]))] = w
                except Exception:
                    continue
        elif isinstance(colw, dict):
            for k, v in colw.items():
                try:
                    if isinstance(k, str) and "," in k:
                        xs, ys = k.split(",", 1)
                        pos = (int(xs), int(ys))
                    elif isinstance(k, (list, tuple)) and len(k) >= 2:
                        pos = (int(k[0]), int(k[1]))
                    else:
                        continue
                    self.col_weight[pos] = float(v)
                except Exception:
                    continue
        self.col_weight_max = max(self.col_weight.values()) if self.col_weight else 1.0

        # 5. Inicializa la lista de agentes con los datos del JSON
        self.robots = ap.AgentList(self, n_robots, Robot)
        for robot, info in zip(self.robots, cfg.get("robots", [])):
            robot.json_setup(info)
            # If robot starts without a mission, send it to nearest resting point so it moves
            if robot.mission is None:
                robot.mission = "RESTING"
                # During setup, 'intended' isn't defined yet; ignore occupancy when picking
                rp = self.closest_pick(robot.position, self.resting_points, lambda p: True)
                robot.target = (rp[0], rp[1], 0) if rp is not None else None

        # Assign robot capabilities and preferred drop points
        try:
            if self.drop_points:
                for rb in self.robots:
                    rb.drop_pref = tuple(self.drop_points[rb.id % len(self.drop_points)])
                    # Robot capabilities: 
                    # - Robots 1&2 (id 0,1): Can access levels 1&2 (low-medium levels)
                    # - Robots 3&4 (id 2,3): Can access levels 3&4 (high levels)
                    if rb.id <= 1:
                        rb.access_levels = [1, 2]  # Robots 1&2 access levels 1&2
                    else:
                        rb.access_levels = [3, 4]  # Robots 3&4 access levels 3&4
                    
                    # Backward compatibility with old system
                    rb.can_access_high = (rb.id >= 2)
        except Exception:
            pass

        # 6. Inicializa indicadores y datos de Q-learning
        self.n_features = N_FEATURES
        self.global_epsilon = EPSILON_START
        # Auto-cycle reset is disabled by default; visualization can enable it
        self.auto_cycle_reset = False
        # Expose cycle target for visualizer HUD
        self.CYCLE_DELIVERIES_TARGET = CYCLE_DELIVERIES_TARGET
        # Counter to cycle drop points when seeding missions so early missions map predictably
        self._mission_seed_counter = 0

        # Silent pretrained weight loading
        if PRETRAIN_ENABLED and os.path.exists("W_linear.npy"):
            try:
                self.global_weights = np.load("W_linear.npy").astype(np.float32)
                if self.global_weights.shape[0] != N_FEATURES:
                    self.global_weights = np.zeros(N_FEATURES, dtype=np.float32)
            except Exception:
                self.global_weights = np.zeros(N_FEATURES, dtype=np.float32)
        else:
            self.global_weights = np.zeros(N_FEATURES, dtype=np.float32)

        # Estado de planificación y misiones
        self.intended = {}  # dict[(x,y)] -> [Robot,...] para resolución de conflictos
        self.current_missions = {}  # ROBOT_ID -> {box_location, target, mission}
        self.pending_missions = []
        self.forced_wait_by_conflict = set()
        
        # Box visibility tracking for visualization
        self.picked_boxes = set()  # Track which boxes are currently picked up
        self.delivered_boxes = set()  # Track which boxes have been delivered (training mode)
        self.available_spawn_points = []  # Potential respawn locations for boxes

        # --- Métricas / logging ---
        self.stats = {
            "step": 0,
            "reward_hist": [],
            "success_hist": [],
            "delivery_hist": [],
            "pickup_hist": [],
            "td_hist": [],
            "deliveries": 0,
            "pickups": 0,
            "conflicts": 0,
            "moves": 0,
            "waits": 0,
            "recharges": 0,
            "bumps": 0,
            "forced_waits": 0,
            # Per-step event histograms for plotting/export
            "bump_hist": [],
            "forced_wait_hist": [],
            # Diagnostics: action opportunities vs choices
            "pickup_opportunities": 0,
            "pickup_missed": 0,
            "drop_opportunities": 0,
            "drop_missed": 0,
            "dist_reduced_sum": 0.0,
            "dist_steps": 0,
            "episodes": 0,
            "episode_rewards": [],
            "avg_reward": 0.0,
            "epsilon": self.global_epsilon
        }
        # Unity actions envelope: per-tick events collected in step()
        self.action_events = []
        # Backward-compat for external scripts that expect _stats
        self._stats = self.stats

        # Sembrar misiones aleatorias para pruebas
        try:
            # Use instance cycle target (allows dynamic adjustment for visualization modes)
            self.seed_random_missions(self.CYCLE_DELIVERIES_TARGET)
        except Exception:
            pass

    def reset_cycle(self):
        """Reset missions and per-cycle counters after reaching delivery target."""
        # Bump a simple cycle counter stored in episodes for visibility
        try:
            self.stats["episodes"] = int(self.stats.get("episodes", 0)) + 1
        except Exception:
            self.stats["episodes"] = 1

        # Clear mission state
        self.current_missions = {}
        self.pending_missions = []
        self.intended = {}
        self.forced_wait_by_conflict = set()

        # Send robots to resting and clear transient flags
        for rb in getattr(self, 'robots', []):
            rb.carrying = False
            rb.mission = "RESTING"
            rp = self.closest_pick(rb.position, self.resting_points, self.resting_point_free)
            rb.target = (rp[0], rp[1], 0) if rp is not None else None
            rb.proposal = None
            rb.box_location = None

        # Reset per-cycle counters and short histories for clarity in the HUD
        for k in ["deliveries", "pickups", "conflicts", "moves", "waits", "recharges"]:
            try:
                self.stats[k] = 0
            except Exception:
                pass
        try:
            self.stats["reward_hist"] = []
            self.stats["success_hist"] = []
            self.stats["delivery_hist"] = []
            self.stats["pickup_hist"] = []
            self.stats["td_hist"] = []
            self.stats["avg_reward"] = 0.0
        except Exception:
            pass

        # Seed a fresh batch of missions (aiming for the new cycle target)
        try:
            self.seed_random_missions(self.CYCLE_DELIVERIES_TARGET)
        except Exception:
            pass

    def set_cycle_target(self, deliveries:int):
        """Dynamically adjust how many deliveries constitute a visualization 'cycle'.
        Updates the instance variable and reseeds missions accordingly.
        """
        try:
            deliveries = int(deliveries)
            if deliveries <= 0:
                return
            self.CYCLE_DELIVERIES_TARGET = deliveries
            # Reseed missions to match new cycle size if current pending is empty
            if not self.pending_missions:
                try:
                    self.seed_random_missions(self.CYCLE_DELIVERIES_TARGET)
                except Exception:
                    pass
        except Exception:
            pass

    def inbound(self, p : tuple):
        x, y = p
        return (0 <= x < self.W and 0 <= y < self.H)

    def is_blocked(self, p : tuple):
        return (p in self.occupied)

    def _initialize_box_spawn_points(self):
        """Initialize potential spawn points for box respawning."""
        self.available_spawn_points = []
        service_points = set(self.drop_points + self.recharge_points + self.spawn_points + self.resting_points)
        
        # Find free cells that are not service points and not too close to them
        for x in range(self.W):
            for y in range(self.H):
                pos = (x, y)
                if self.cell_is_free(pos) and pos not in service_points:
                    # Check if not too close to service points (at least 2 cells away)
                    too_close = False
                    for service_pos in service_points:
                        if manhattan(pos, service_pos) < 2:
                            too_close = True
                            break
                    if not too_close:
                        self.available_spawn_points.append(pos)

    def handle_box_pickup(self, robot, box_location):
        """Handle visual pickup - mark box as picked and schedule respawn."""
        if isinstance(box_location, (list, tuple)) and len(box_location) >= 2:
            box_key = (box_location[0], box_location[1])
            self.picked_boxes.add(box_key)
    
    def handle_box_delivery(self, robot, box_location):
        """Handle delivery - optionally respawn the box at a new location."""
        # Skip delivery if training episode is already terminated
        if getattr(self, 'episode_terminated', False):
            return
            
        if isinstance(box_location, (list, tuple)) and len(box_location) >= 2:
            box_key = (box_location[0], box_location[1])
            if box_key in self.picked_boxes:
                self.picked_boxes.remove(box_key)
                # Only respawn if respawning is enabled (simulation mode)
                if getattr(self, 'box_respawn_enabled', True):
                    self._respawn_box(box_location)
                else:
                    # In training mode, mark box as permanently delivered
                    if not hasattr(self, 'delivered_boxes'):
                        self.delivered_boxes = set()
                    self.delivered_boxes.add(box_key)
    
    def _respawn_box(self, original_box_location):
        """Respawn a box at a new random location with the same level."""
        if not self.available_spawn_points:
            return  # No spawn points available
            
        # Find the original box to get its level
        original_level = 1  # Default level
        box_id = None
        for i, box in enumerate(self.boxes):
            if isinstance(box, dict) and 'pos' in box:
                pos = box['pos']
                if (isinstance(pos, (list, tuple)) and len(pos) >= 2 and 
                    pos[0] == original_box_location[0] and pos[1] == original_box_location[1]):
                    original_level = pos[2] if len(pos) >= 3 else 1
                    box_id = i
                    break
        
        if box_id is not None:
            # Choose a random spawn point
            new_pos = random.choice(self.available_spawn_points)
            # Update box position
            self.boxes[box_id]['pos'] = [new_pos[0], new_pos[1], original_level]

    def is_rack_cell(self, pos):
        """Check if a position is a rack (blocked) cell"""
        return not self.inbound(pos) or self.is_blocked(pos)
    
    def is_narrow_aisle(self, pos):
        """Check if position is in a narrow aisle between racks (should use guidance lines)"""
        if not isinstance(pos, (tuple, list)) or len(pos) < 2:
            return False
            
        x, y = int(pos[0]), int(pos[1])
        
        # Check if we're between two racks horizontally (narrow vertical aisle)
        left_blocked = self.is_rack_cell((x-1, y))
        right_blocked = self.is_rack_cell((x+1, y))
        
        # If both sides are blocked, we're in a narrow aisle
        if left_blocked and right_blocked:
            return True
            
        return False
    
    def is_guidance_line_entry(self, pos, target_box=None):
        """Check if position is a proper guidance line entry point"""
        if target_box is not None:
            return is_on_guidance_line_for_box(self, pos, target_box)
        return False
    
    def cell_is_free(self, p : tuple):
        return (self.inbound(p) and not self.is_blocked(p))

    def recharge_point_free(self, p:tuple):
        return (p in self.recharge_points) and (p not in self.intended.keys())

    def resting_point_free(self, p:tuple):
        return (p in self.resting_points) and (p not in self.intended.keys())

    def get_available_drop_point(self, robot_id):
        """Get an available drop point for a robot, ensuring no conflicts"""
        if not self.drop_points:
            return None
            
        # Check if robot already has a reserved drop point
        if robot_id in self.drop_point_assignments:
            reserved_point = self.drop_point_assignments[robot_id]
            if reserved_point in self.reserved_drop_points:
                return reserved_point
        
        # Find an unreserved drop point
        for drop_point in self.drop_points:
            if drop_point not in self.reserved_drop_points:
                # Reserve this drop point for the robot
                self.reserved_drop_points.add(drop_point)
                self.drop_point_assignments[robot_id] = drop_point
                return drop_point
        
        # If all are reserved, use round-robin as fallback
        fallback_point = self.drop_points[robot_id % len(self.drop_points)]
        return fallback_point
    
    def release_drop_point(self, robot_id):
        """Release a robot's drop point reservation"""
        if robot_id in self.drop_point_assignments:
            drop_point = self.drop_point_assignments[robot_id]
            self.reserved_drop_points.discard(drop_point)
            del self.drop_point_assignments[robot_id]

    def add_mission_to_queue(self, box_location:tuple, target:tuple, mission:str):
        self.pending_missions.append((box_location, target, mission))

    def closest_pick(self, robot_pos:tuple, cell_list, free_fun):
        best = None
        best_d = None
        for p in cell_list:
            d = manhattan(robot_pos, p)
            if (best_d is None or d < best_d) and free_fun(p):
                best = p
                best_d = d
        return best

    def assign_all_pending_nearest(self):
        """Assign each pending mission to the nearest eligible robot (greedy).
        Elegible: mission None/RESTING, battery >=15 (else reroute to recharge), correct type if level requires.
        No random choice: determinista por orden de lista de misiones.
        """
        if not self.pending_missions:
            return
        remaining = []
        # Precompute a list of free robots we can still allocate this pass
        # We'll update as we assign so each robot gets at most one new mission.
        for bx_loc, tgt, miss in list(self.pending_missions):
            # Skip inaccessible box for now
            try:
                if bx_loc is not None and not self.box_is_accessible(bx_loc):
                    remaining.append((bx_loc, tgt, miss))
                    continue
            except Exception:
                pass
            # Determine capability requirement - check if robot can access box level
            box_level = None
            try:
                if bx_loc is not None and len(bx_loc) > 2:
                    box_level = int(bx_loc[2])
            except Exception:
                box_level = 1  # Default level
                
            candidates = []
            for rb in self.robots:
                if rb.mission not in (None, "RESTING"):
                    continue
                # Skip robots that can't access this box level
                if box_level is not None:
                    robot_access_levels = getattr(rb, 'access_levels', [1, 2])
                    if box_level not in robot_access_levels:
                        continue
                # Battery routing
                if rb.battery < 15:
                    chg = self.closest_pick(rb.position, self.recharge_points, self.recharge_point_free)
                    if chg is not None:
                        rb.mission = "RECHARGE"
                        rb.target = (chg[0], chg[1], 0)
                    else:
                        rb.mission = "RESTING"
                    continue
                candidates.append(rb)
            if not candidates:
                remaining.append((bx_loc, tgt, miss))
                continue
            # Choose nearest by Manhattan distance to the box location (x,y)
            try:
                bx_xy = (bx_loc[0], bx_loc[1]) if isinstance(bx_loc, (list, tuple)) else None
            except Exception:
                bx_xy = None
            if bx_xy is None:
                remaining.append((bx_loc, tgt, miss))
                continue
            best = min(candidates, key=lambda r: manhattan(r.position, bx_xy))
            best.mission = miss
            
            # Assign unique drop point for this robot
            if miss == "DELIVERY":
                unique_drop_point = self.get_available_drop_point(best.id)
                if unique_drop_point is not None:
                    best.target = (unique_drop_point[0], unique_drop_point[1], 0)
                else:
                    best.target = tgt  # Fallback to original target
            else:
                best.target = tgt
                
            best.box_location = bx_loc
            self.current_missions[best.id] = {"box_location": bx_loc, "target": best.target, "mission": miss}
        self.pending_missions = remaining

    # Backward compatibility wrapper (old signature still called elsewhere)
    def assign_mission(self, box_location:tuple, target:tuple, mission:str):
        # If a single mission is passed, append then batch assign; else just batch assign existing queue
        if box_location is not None and target is not None and mission is not None:
            self.pending_missions.append((box_location, target, mission))
        self.assign_all_pending_nearest()

    # ================= Episodic training helpers =================
    def setup_episode_based_training(self):
        """Reset robots to random positions with fresh state for episodic training."""
        # Reset box delivery tracking for training episodes
        if hasattr(self, 'delivered_boxes'):
            self.delivered_boxes.clear()
        if hasattr(self, 'picked_boxes'):
            self.picked_boxes.clear()
        
        # Initialize episode termination flag for training
        self.episode_terminated = False
        
        # Track episode deliveries for training mode
        if not hasattr(self, 'episode_delivery_count'):
            self.episode_delivery_count = 0
        else:
            self.episode_delivery_count = 0
            
        try:
            free_cells = [(x, y) for x in range(self.W) for y in range(self.H) if self.cell_is_free((x, y))]
        except Exception:
            free_cells = []
        if len(free_cells) < len(getattr(self, 'robots', [])):
            # fallback allow duplicates
            available_positions = free_cells + [(x, y) for x in range(self.W) for y in range(self.H) if (x, y) not in self.occupied]
        else:
            available_positions = list(free_cells)
        for robot in self.robots:
            if available_positions:
                spawn_pos = random.choice(available_positions)
                robot.position = spawn_pos
                try:
                    available_positions.remove(spawn_pos)
                except ValueError:
                    pass
            robot.battery = 100
            robot.carrying = False
            robot.mission = "RESTING"
            robot.target = None
            robot.proposal = None
            robot.box_location = None
            robot.deliveries_this_episode = 0

    def check_episode_success(self):
        """Success when all robots have delivered at least once this episode."""
        for rb in self.robots:
            if not hasattr(rb, 'deliveries_this_episode') or rb.deliveries_this_episode == 0:
                return False
        return True

    def check_training_episode_complete(self):
        """Check if training episode should end (max 1 delivery per robot)."""
        if not getattr(self, 'training_mode', False):
            return self.check_episode_success()  # Use regular success criteria for visualization
        
        # In training mode: terminate when ALL robots have delivered at least once
        # This ensures successful episodes while limiting deliveries
        all_delivered = True
        for rb in self.robots:
            deliveries = getattr(rb, 'deliveries_this_episode', 0)
            if deliveries == 0:
                all_delivered = False
                break
        
        return all_delivered

    def _update_epsilon_episodic(self, episode:int, total_episodes:int):
        """Quadratic episode-based epsilon decay."""
        if getattr(self, 'epsilon_override', None) is not None:
            self.global_epsilon = float(self.epsilon_override)
        else:
            progress = episode / max(1, total_episodes)
            self.global_epsilon = float(EPSILON_END + (EPSILON_START - EPSILON_END) * (1 - progress) ** 2)
        self.stats['epsilon'] = self.global_epsilon

    # --- utilidades nuevas ---
    def get_col_weight(self, pos_xy:tuple):
        if not isinstance(pos_xy, (list, tuple)) or len(pos_xy) < 2:
            return 1.0
        return float(self.col_weight.get((pos_xy[0], pos_xy[1]), 1.0))

    def box_is_accessible(self, box_location:tuple):
        try:
            if not isinstance(box_location, (list, tuple)) or len(box_location) < 2:
                return False
            bx, by = box_location[0], box_location[1]
            
            # Check if box is already picked up (visually disappeared)
            box_key = (int(bx), int(by))
            if hasattr(self, 'picked_boxes') and box_key in self.picked_boxes:
                return False  # Box is already picked up, not accessible
            
            # In training mode without respawning, check if box was delivered
            if getattr(self, 'training_mode', False) and not getattr(self, 'box_respawn_enabled', True):
                # Track delivered boxes that shouldn't respawn
                delivered_boxes = getattr(self, 'delivered_boxes', set())
                if box_key in delivered_boxes:
                    return False  # Box was delivered and not respawned
            
            return len(approach_cells_to_box(self, (bx, by), None)) > 0
        except Exception:
            return False

    def seed_random_missions(self, n:int=3):
        # Filter boxes based on available robot capabilities with new level system
        locs = []
        # Get all access levels available from current robots
        available_levels = set()
        for rb in self.robots:
            robot_levels = getattr(rb, 'access_levels', [1, 2])
            available_levels.update(robot_levels)
        
        for b in self.boxes:
            pos = b.get('pos') if isinstance(b, dict) else None
            if isinstance(pos, (list, tuple)) and len(pos) >= 2:
                if len(pos) >= 3:
                    level = int(pos[2]) if pos[2] is not None else 1
                    # Include box only if we have robots that can access this level
                    if level in available_levels:
                        locs.append(tuple(pos[:3]))
                else:
                    locs.append((pos[0], pos[1], 1))  # Default to level 1
        if not locs:
            if not getattr(self, '_warned_no_locs', False):
                print("[WARN] No box locations available for missions.")
                self._warned_no_locs = True
            return
        if not self.drop_points:
            if not getattr(self, '_warned_no_drops', False):
                print("[WARN] No drop points configured - cannot create delivery missions.")
                self._warned_no_drops = True
            return
        k = min(n, len(locs))
        random.shuffle(locs)
        for i in range(k):
            loc = locs[i]
            # Use available drop point system instead of round-robin
            # For now, we'll assign drop points during robot assignment, not during mission creation
            # This allows for proper reservation management
            dummy_dp = self.drop_points[0] if self.drop_points else (0, 0)
            tgt3 = (dummy_dp[0], dummy_dp[1], 0)
            self.add_mission_to_queue(loc, tgt3, "DELIVERY")
        # Asignar inmediatamente usando política "nearest"
        self.assign_all_pending_nearest()

    def _validate_config(self, cfg:dict):
        # Cajas
        for i, b in enumerate(cfg.get('boxes', [])):
            if not isinstance(b, dict):
                print(f"[WARN] Box idx {i} invalid format")
                continue
            pos = b.get('pos')
            has_slot = ('rack_id' in b) and isinstance(b.get('slot'), dict)
            if pos is None:
                # If slot-based addressing is present, it's valid; we'll map to pos at setup
                if not has_slot:
                    print(f"[WARN] Box idx {i} missing pos (x,y,h)")
            else:
                if not isinstance(pos, (list, tuple)) or len(pos) < 3:
                    print(f"[WARN] Box idx {i} pos invalid (expected [x,y,h])")
        # Tags
        valid = {"DROP", "CHARGE", "SPAWN", "REST"}
        for t in cfg.get('tags', []):
            ty = t.get('type')
            if ty not in valid:
                print(f"[WARN] Unknown tag type: {ty}")
            pos = t.get('pos')
            if not isinstance(pos, (list, tuple)) or len(pos) < 2:
                print(f"[WARN] Tag {ty} invalid pos: {pos}")
        # Pesos de columna
        colw = cfg.get('col_weights')
        if colw is not None and not isinstance(colw, (list, dict)):
            print("[WARN] col_weights must be list or dict")

    def _dest_after(self, rb, act=None):
        """Where this robot will be next step given its current (or provided) proposal."""
        a = rb.proposal if act is None else act
        return next_pos_from_action(self, rb.position, a)

    def get_robot_priority(self, robot):
        """Calculate robot priority for conflict resolution. Higher = more important."""
        priority = 0
        
        # Mission-based priority
        if getattr(robot, 'carrying', False):
            priority += 100  # Delivery has highest priority
        elif getattr(robot, 'mission', None) == 'DELIVERY':
            priority += 50   # Going to pickup is important
        elif getattr(robot, 'mission', None) == 'RECHARGE':
            priority += 30   # Recharging is medium priority
        
        # Battery urgency
        battery = float(getattr(robot, 'battery', 100))
        if battery < 15:
            priority += 75   # Critical battery - emergency priority
        elif battery < 30:
            priority += 25   # Low battery gets some priority
        
        # Slight randomization to break ties fairly
        priority += (robot.id * 0.1)  # Small tie-breaker based on ID
        
        return priority

    def get_alternative_moves(self, robot):
        """Get all valid alternative moves for a robot, sorted by preference."""
        x, y = robot.position
        alternatives = []
        
        # Get all possible directions
        for action, (dx, dy) in DIRS.items():
            new_pos = (x + dx, y + dy)
            if self.cell_is_free(new_pos):
                alternatives.append((action, new_pos))
        
        # Sort alternatives by distance to robot's goal
        if hasattr(robot, 'target') and robot.target:
            goal = robot.target[:2] if len(robot.target) >= 2 else robot.target
            alternatives.sort(key=lambda alt: manhattan(alt[1], goal))
        elif hasattr(robot, 'box_location') and robot.box_location and not getattr(robot, 'carrying', False):
            goal = robot.box_location[:2] if len(robot.box_location) >= 2 else robot.box_location
            alternatives.sort(key=lambda alt: manhattan(alt[1], goal))
        
        return alternatives

    # ================= FIXED STEP PIPELINE (CLEAN REPLACEMENT) =================
    def step(self):
        """Advance one simulation tick (planning -> conflict resolution -> action -> bookkeeping)."""
        self._update_epsilon()
        self._reset_step_counters()
        self._phase_plan()
        self.resolve_conflicts()
        self._phase_act()
        self._post_step_updates()

    def resolve_conflicts(self, max_passes=3):
        """Enhanced multi-pass resolver with priority-based resolution and alternative routing."""
        self.forced_wait_by_conflict = set()
        
        for pass_num in range(max_passes):
            # Build intended destinations map
            intended = {}
            for rb in self.robots:
                dest = self._dest_after(rb)
                intended.setdefault(dest, []).append(rb)
            
            conflicts_found = False
            
            # Resolve many-to-one conflicts with priority and alternatives
            # Create a copy of items to avoid RuntimeError from modification during iteration
            conflicts_to_resolve = [(dest, robots[:]) for dest, robots in intended.items() if len(robots) > 1]
            
            for dest, robots in conflicts_to_resolve:
                conflicts_found = True
                
                # Sort robots by priority (highest first)
                robots_by_priority = sorted(robots, key=self.get_robot_priority, reverse=True)
                winner = robots_by_priority[0]  # Highest priority wins
                
                # Try to find alternatives for lower priority robots
                for loser in robots_by_priority[1:]:
                    found_alternative = False
                    
                    # Try alternative moves (only on first pass to avoid confusion)
                    if pass_num == 0:
                        alternatives = self.get_alternative_moves(loser)
                        for alt_action, alt_dest in alternatives:
                            # Check if this alternative destination is free from other robots
                            # Don't modify intended dict during resolution - just check original conflicts
                            other_robots_at_dest = [r for r in self.robots if r != loser and self._dest_after(r) == alt_dest]
                            if len(other_robots_at_dest) == 0:
                                # Alternative is free, use it
                                loser.proposal = alt_action
                                found_alternative = True
                                break
                    
                    # If no alternative found, force to wait
                    if not found_alternative:
                        loser.proposal = "WAIT"
                        self.forced_wait_by_conflict.add(loser.id)
            
            # Resolve head-on swaps with priority system
            swap_conflicts = []
            for rb1 in self.robots:
                for rb2 in self.robots:
                    if rb1.id >= rb2.id:
                        continue
                    dest1 = self._dest_after(rb1)
                    dest2 = self._dest_after(rb2)
                    if rb1.position == dest2 and rb2.position == dest1:
                        swap_conflicts.append((rb1, rb2))
            
            for rb1, rb2 in swap_conflicts:
                conflicts_found = True
                priority1 = self.get_robot_priority(rb1)
                priority2 = self.get_robot_priority(rb2)
                
                # Lower priority robot waits
                if priority1 < priority2:
                    loser = rb1
                else:
                    loser = rb2
                
                # Try alternative for the loser (first pass only)
                found_alternative = False
                if pass_num == 0:
                    alternatives = self.get_alternative_moves(loser)
                    for alt_action, alt_dest in alternatives[:2]:  # Try top 2 alternatives
                        # Check if alternative is truly free (no other robots going there)
                        if alt_dest not in [self._dest_after(r) for r in self.robots if r != loser]:
                            loser.proposal = alt_action
                            found_alternative = True
                            break
                
                # Force to wait if no alternative
                if not found_alternative:
                    loser.proposal = "WAIT"
                    self.forced_wait_by_conflict.add(loser.id)
            
            if not conflicts_found:
                break
        
        # Update stats
        self.stats["conflicts"] += len(self.forced_wait_by_conflict)
        self._forced_waits_this_step = len(self.forced_wait_by_conflict)

    def _update_epsilon(self):
        self.stats["step"] += 1
        if getattr(self, 'epsilon_override', None) is not None:
            self.global_epsilon = float(self.epsilon_override)
        else:
            try:
                tau = float(EPSILON_TAU)
            except Exception:
                tau = max(1.0, DECAY_STEPS / 4.0)
            self.global_epsilon = float(
                EPSILON_END + (EPSILON_START - EPSILON_END) * np.exp(-self.stats["step"] / tau)
            )
        self.stats["epsilon"] = self.global_epsilon

    def _reset_step_counters(self):
        self.intended = {}
        self.forced_wait_by_conflict = set()
        self.action_events = []
        self._delivered_this_step = 0
        self._picked_this_step = 0
        self._bumps_this_step = 0
        self._forced_waits_this_step = 0

    def _phase_plan(self):
        # Try to assign pending missions to available robots first
        try:
            self.assign_all_pending_nearest()
        except Exception:
            pass
        
        for robot in self.robots:
            if robot.mission is None:
                robot.mission = "RESTING"
                rp = self.closest_pick(robot.position, self.resting_points, self.resting_point_free)
                robot.target = (rp[0], rp[1], 0) if rp is not None else None
            if getattr(robot, 'battery', 100) < 10 and not getattr(robot, 'carrying', False):
                chg = self.closest_pick(robot.position, self.recharge_points, self.recharge_point_free)
                if chg is None and self.recharge_points:
                    chg = min(self.recharge_points, key=lambda p: manhattan(robot.position, p))
                if chg is not None:
                    robot.mission = "RECHARGE"
                    robot.target = (chg[0], chg[1], 0)
            if robot.mission == "RESTING":
                tgt = robot.target
                if tgt is not None:
                    tgt_xy = tuple(tgt[:2]) if isinstance(tgt, (list, tuple)) and len(tgt) >= 2 else tuple(tgt)
                    if tgt_xy in self.recharge_points:
                        rp = self.closest_pick(robot.position, self.resting_points, self.resting_point_free)
                        robot.target = (rp[0], rp[1], 0) if rp is not None else None
            box_loc = self.current_missions.get(robot.id, {}).get("box_location", None)
            robot.plan(box_loc)
            dest = next_pos_from_action(self, robot.position, robot.proposal)
            self.intended.setdefault(dest, []).append(robot)

    def _phase_act(self):
        for robot in self.robots:
            if robot.mission is None:
                continue
            robot.act()

    def _post_step_updates(self):
        try:
            self.assign_mission(None, None, None)
        except Exception:
            pass
        # More aggressive mission seeding - always keep missions available
        try:
            available_robots = sum(1 for r in self.robots if r.mission in (None, "RESTING"))
            pending_count = len(self.pending_missions)
            if pending_count < available_robots and int(self.stats.get("deliveries", 0)) < 999:
                missions_needed = max(2, available_robots - pending_count)
                self.seed_random_missions(n=missions_needed)
        except Exception:
            pass
        if self.stats["reward_hist"]:
            recent = self.stats["reward_hist"][-100:] if len(self.stats["reward_hist"]) >= 100 else self.stats["reward_hist"]
            self.stats["avg_reward"] = sum(recent) / len(recent)
        try:
            self.stats["delivery_hist"].append(1 if self._delivered_this_step > 0 else 0)
            self.stats["pickup_hist"].append(1 if self._picked_this_step > 0 else 0)
            self.stats["bump_hist"].append(int(self._bumps_this_step))
            self.stats["forced_wait_hist"].append(int(self._forced_waits_this_step))
        except Exception:
            pass
        try:
            if bool(getattr(self, 'auto_cycle_reset', False)) and int(self.stats.get("deliveries", 0)) >= int(self.CYCLE_DELIVERIES_TARGET):
                print(f"Cycle complete: {self.stats.get('deliveries',0)} deliveries. Resetting...")
                self.reset_cycle()
        except Exception:
            pass

    def run(self, steps=1000):
        """Run the simulation for a specified number of steps."""
        for _ in range(steps):
            self.step()
        return self
    # ================= END FIXED STEP PIPELINE =================

    def get_state_dict(self):
        """Return current state for visualization"""
        robot_states = []
        for robot in self.robots:
            robot_states.append({
                'id': robot.id,
                'position': robot.position,
                'carrying': robot.carrying,
                'battery': robot.battery,
                'mission': robot.mission,
                'target': robot.target,
                'r_type': robot.r_type
            })
        
        return {
            'step': self.stats["step"],
            'robots': robot_states,
            'stats': self.stats.copy(),
            'epsilon': self.global_epsilon,
            'occupied': list(self.occupied),
            'drop_points': self.drop_points,
            'recharge_points': self.recharge_points,
            'spawn_points': self.spawn_points,
            'W': self.W,
            'H': self.H
        }

    def print_progress(self, episode=None):
        """Print training progress"""
        if episode is not None:
            print(f"Episode {episode}")
        print(f"Step: {self.stats['step']}")
        print(f"Epsilon: {self.global_epsilon:.3f}")
        print(f"Avg Reward: {self.stats['avg_reward']:.3f}")
        print(f"Deliveries: {self.stats['deliveries']}")
        print(f"Pickups: {self.stats['pickups']}")
        print(f"Conflicts: {self.stats['conflicts']}")
        print("-" * 40)

    def save_weights(self, filename="W_linear.npy"):
        """Save current weights silently"""
        try:
            np.save(filename, self.global_weights)
        except Exception as e:
            print(f"Error saving weights: {e}")

    def load_weights(self, filename="W_linear.npy"):
        """Load weights from file silently. Returns True if loaded, False otherwise."""
        try:
            if not os.path.exists(filename):
                return False
            arr = np.load(filename).astype(np.float32)
            if arr.shape[0] != N_FEATURES:
                print(f"Error: weight dimension mismatch in {filename}")
                return False
            self.global_weights = arr
            return True
        except Exception:
            return False

    def end(self):
        # Guardar pesos si no usamos preentrenados
        try:
            if not PRETRAIN_ENABLED and hasattr(self, 'global_weights'):
                self.save_weights("W_linear.npy")
        except Exception:
            pass

    def serialize_for_unity(self):
        """Build the exact envelope the Unity client expects."""
        # robots array
        robots_json = []
        try:
            for rb in getattr(self, "robots", []):
                x, y = rb.position
                robots_json.append({
                    "id": int(getattr(rb, "id", -1)),
                    "x": int(x),
                    "y": int(y),
                    "heading": int(getattr(rb, "last_heading", 0)),
                    "action": str(getattr(rb, "last_action_str", "idle"))
                })
        except Exception:
            robots_json = []

        # boxes array (static from config); 'available' via accessibility check
        boxes_json = []
        try:
            for b in getattr(self, "boxes", []):
                pos = b.get("pos") if isinstance(b, dict) else None
                if isinstance(pos, (list, tuple)) and len(pos) >= 3:
                    bx, by, lvl = int(pos[0]), int(pos[1]), int(pos[2])
                    avail = False
                    try:
                        avail = bool(self.box_is_accessible((bx, by, lvl)))
                    except Exception:
                        avail = False
                    boxes_json.append({
                        "x": bx,
                        "y": by,
                        "level": lvl,
                        "available": avail
                    })
        except Exception:
            boxes_json = []

        # actions array (already lowercase strings)
        try:
            actions_json = list(self.action_events) if isinstance(self.action_events, list) else []
        except Exception:
            actions_json = []

        # episode/tick flags
        ticks = int(self.stats.get("step", 0)) if isinstance(self.stats, dict) else 0
        # Mark done when a delivery cycle target is reached (but before auto reset)
        ep_done = False
        try:
            ep_done = bool(self.stats.get("deliveries", 0) >= int(self.CYCLE_DELIVERIES_TARGET))
        except Exception:
            ep_done = False

        state = {
            "ticks": ticks,
            "episode_done": ep_done,
            "robots": robots_json,
            "boxes": boxes_json,
            "actions": actions_json,
        }

        # Full envelope
        envelope = {
            "initialized": True,
            "running": True,
            "state": state
        }
        return envelope

"""Deprecated step-based train_model removed in favor of episodic training.
For backward compatibility, provide a thin wrapper that calls train_model_episodic
with equivalent arguments. Users should migrate to train_model_episodic directly."""
def train_model(episodes=1000, steps_per_episode=300, config_path='layout.json',
                save_every=100, weights_dir="weights", summary_window=50, n_robots=None):
    return train_model_episodic(episodes=episodes, steps_per_episode=steps_per_episode,
                                config_path=config_path, save_every=save_every,
                                weights_dir=weights_dir, summary_window=summary_window,
                                n_robots=n_robots)

def run_simulation(steps=1000, config_path='layout.json', visualize=False):
    """Run a single simulation with optional visualization."""
    params = {'config_path': config_path}
    model = Warehouse(parameters=params)
    model.setup()

    if visualize and VISUALIZATION_ENABLED:
        try:
            try:
                from visualize import WarehouseVisualizer
            except Exception:
                WarehouseVisualizer = None
            if WarehouseVisualizer is not None:
                viz = WarehouseVisualizer(model, cell_size=30, fps=3)
                viz.run(steps)
            else:
                print("WarehouseVisualizer not available. Running headless.")
                for _ in range(steps):
                    model.step()
        except Exception as e:
            print(f"Visualization error: {e}. Running headless.")
            for _ in range(steps):
                model.step()
    else:
        for _ in range(steps):
            model.step()
    return model

# ================= Episodic / Progressive Training ============================
def train_model_episodic(episodes=1000, steps_per_episode=300, config_path='layout.json',
                         save_every=100, weights_dir="weights", summary_window=50, n_robots=None):
    """Episode-based training with random spawning, success tracking, and episodic epsilon decay."""
    print(f"Episode-based Training: {episodes} episodes × {steps_per_episode} steps")
    print("Success criteria: all robots deliver at least once per episode")
    if n_robots:
        print(f"Training with {n_robots} robots")
    print(f"Config: {config_path} | Weights: {weights_dir}")
    print("-" * 80)

    os.makedirs(weights_dir, exist_ok=True)
    default_weights = os.path.join(weights_dir, "W_linear.npy")
    best_weights = os.path.join(weights_dir, "W_linear_best.npy")

    best_success_rate = 0.0
    total_steps = 0
    episode_success_history = []
    episode_rewards = []
    deliveries_per_episode = []

    recent_success_rate = 0.0

    for episode in range(episodes):
        params = {'config_path': config_path}
        model = Warehouse(parameters=params)
        model.setup()
        model.auto_cycle_reset = False
        if n_robots and n_robots < len(model.robots):
            model.robots = model.robots[:n_robots]
        if episode > 0:
            if not model.load_weights(default_weights):
                model.load_weights(best_weights)

        model.setup_episode_based_training()
        # DISABLE box respawning during training for clean metrics
        model.training_mode = True
        model.box_respawn_enabled = False
        
        # Compute episodic epsilon (quadratic decay over episodes)
        model._update_epsilon_episodic(episode, episodes)
        # Freeze epsilon during intra-episode steps so step-based decay in step() doesn't override it
        # (step() calls _update_epsilon each tick; the override keeps epsilon constant for this episode)
        model.epsilon_override = model.global_epsilon

        episode_reward = 0.0
        episode_deliveries = 0
        for step in range(steps_per_episode):
            model.step()
            if getattr(model, '_delivered_this_step', 0) > 0:
                episode_deliveries += getattr(model, '_delivered_this_step', 0)
            if model.stats['reward_hist']:
                episode_reward += model.stats['reward_hist'][-1]
            total_steps += 1
            
            # Early termination: check if episode was terminated during delivery processing
            if (getattr(model, 'episode_terminated', False) or 
                model.check_training_episode_complete()):
                break

        success = model.check_episode_success()
        episode_success_history.append(1 if success else 0)
        episode_rewards.append(episode_reward)
        deliveries_per_episode.append(episode_deliveries)

        if len(episode_success_history) >= summary_window:
            recent_success_rate = sum(episode_success_history[-summary_window:]) / summary_window
        else:
            recent_success_rate = sum(episode_success_history) / len(episode_success_history)

        if (episode + 1) % summary_window == 0:
            avg_reward = np.mean(episode_rewards[-summary_window:]) if len(episode_rewards) >= summary_window else np.mean(episode_rewards)
            avg_del = np.mean(deliveries_per_episode[-summary_window:]) if len(deliveries_per_episode) >= summary_window else np.mean(deliveries_per_episode)
            progress = (episode + 1) / episodes * 100.0
            print(f"Episodes {episode-summary_window+2:4d}-{episode+1:4d} [{progress:5.1f}%] | "
                  f"Success: {recent_success_rate:5.1%} | Avg Reward: {avg_reward:6.2f} | "
                  f"Deliveries: {avg_del:4.1f} | ε: {model.global_epsilon:.3f}")

        if recent_success_rate > best_success_rate:
            best_success_rate = recent_success_rate
            model.save_weights(best_weights)
        model.save_weights(default_weights)
        if (episode + 1) % save_every == 0:
            model.save_weights(os.path.join(weights_dir, f"W_linear_ep_{episode+1}.npy"))

    print("\nEpisodic training completed!")
    print(f"Best success rate: {best_success_rate:.1%}")
    print(f"Final success rate: {recent_success_rate:.1%}")
    # Persist aggregated episodic statistics onto the final model so export_metrics can access them
    try:
        model.stats['episode_success_history'] = list(episode_success_history)
        model.stats['episode_rewards'] = list(episode_rewards)
        model.stats['deliveries_per_episode'] = list(deliveries_per_episode)
        model.stats['episodes'] = int(episodes)
        model.stats['best_success_rate'] = float(best_success_rate)
        model.stats['final_success_rate'] = float(recent_success_rate)
    except Exception:
        pass
    return model, episode_success_history

def train_single_robot(episodes=300, steps_per_episode=200):
    print("=== Phase 1: Single Robot Navigation ===")
    return train_model_episodic(episodes=episodes, steps_per_episode=steps_per_episode,
                                n_robots=1, weights_dir="weights/phase1")

def train_two_robots(episodes=500, steps_per_episode=250):
    print("=== Phase 2: Two Robot Coordination ===")
    model, history = train_model_episodic(episodes=episodes, steps_per_episode=steps_per_episode,
                                          n_robots=2, weights_dir="weights/phase2")
    try:
        if os.path.exists("weights/phase1/W_linear_best.npy"):
            import shutil
            shutil.copy("weights/phase1/W_linear_best.npy", "weights/phase2/W_linear.npy")
    except Exception:
        pass
    return model, history

def train_full_team(episodes=1000, steps_per_episode=300):
    print("=== Phase 3: Full Team Optimization ===")
    model, history = train_model_episodic(episodes=episodes, steps_per_episode=steps_per_episode,
                                          n_robots=None, weights_dir="weights/phase3")
    try:
        if os.path.exists("weights/phase2/W_linear_best.npy"):
            import shutil
            shutil.copy("weights/phase2/W_linear_best.npy", "weights/phase3/W_linear.npy")
    except Exception:
        pass
    return model, history

def progressive_training_strategy():
    print("=== Progressive Training Strategy ===")
    model1, history1 = train_single_robot(episodes=300)
    success1 = sum(history1[-50:]) / min(50, len(history1)) if history1 else 0.0
    print(f"Phase 1 final success rate: {success1:.1%}")
    model2, history2 = train_two_robots(episodes=500)
    success2 = sum(history2[-50:]) / min(50, len(history2)) if history2 else 0.0
    print(f"Phase 2 final success rate: {success2:.1%}")
    model3, history3 = train_full_team(episodes=700)
    success3 = sum(history3[-50:]) / min(50, len(history3)) if history3 else 0.0
    print(f"Phase 3 final success rate: {success3:.1%}")
    print("\nProgressive training completed!")
    print(f"Single: {success1:.1%} -> Two: {success2:.1%} -> Full: {success3:.1%}")
    return model3, history3

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "train":
            episodes = int(sys.argv[2]) if len(sys.argv) > 2 else 1000
            train_model(episodes=episodes)
        elif sys.argv[1] == "run":
            steps = int(sys.argv[2]) if len(sys.argv) > 2 else 1000
            visualize = len(sys.argv) > 3 and sys.argv[3] == "--viz"
            run_simulation(steps=steps, visualize=visualize)
        else:
            print("Usage: python warehouse.py [train|run] [episodes/steps] [--viz]")
    else:
        # Default behavior
        try:
            params = {
                'config_path': 'layout.json',
            }
            model = Warehouse(parameters=params)
            model.run(steps=50)
            model.print_progress()
        except FileNotFoundError:
            print("layout.json not found. Place it next to warehouse.py or pass parameters in your runner.")
        except KeyboardInterrupt:
            print("Interrupted by user.")
        except Exception as e:
            print("Simulation error:", e)